let a = "haris";
let b = 123;
let c = true;

export default a;
export {b};
export {c};
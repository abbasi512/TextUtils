import abc, {b,c}from './file1.mjs';
console.log("Default export "+abc);
console.log("Named export "+b);
console.log("Named export "+typeof(c));